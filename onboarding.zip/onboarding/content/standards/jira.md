---
title: "Jira"
date: 2022-04-20T14:13:01+02:00
draft: true
domain: Toolchain
category: Issue Tracking
categoryId: 19
status: Strategic
Owner: TBD
tags: ["standard", "issue tracking", "toolchain"]
categories: ["standards"]

---
