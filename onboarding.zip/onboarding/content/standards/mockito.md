---
title: "Mockito"
date: 2022-04-20T14:13:01+02:00
draft: true
domain: Testing
category: Mocking
categoryId: 29
status: Strategic
Owner: TBD
tags: ["standard", "testing", "mocking"]
categories: ["standards"]

---
