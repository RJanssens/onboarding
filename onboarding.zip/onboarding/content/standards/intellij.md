---
title: "Intellij"
date: 2022-04-20T14:13:01+02:00
draft: true
domain: Development
category: IDE
categoryId: 11
status: Strategic
Owner: TBD
tags: ["standard", "IDE"]
categories: ["standards"]
---
