---
title: "Azure Kubernetes Service (AKS)"
date: 2022-04-20T14:13:01+02:00
draft: true
domain: Kubernetes
category: Container Orchestration
categoryId: 22
status: Strategic
Owner: TBD
tags: ["standard", "kubernetes", "azure"]
categories: ["standards"]
---
