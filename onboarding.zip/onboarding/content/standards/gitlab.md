---
title: "GitLab"
date: 2022-04-20T14:13:01+02:00
draft: true
domain: Toolchain
category: CI-CD Automation
categoryId: 20
status: Strategic
Owner: TBD
tags: ["standard", "ci-cd", "automation"]
categories: ["standards"]
---
