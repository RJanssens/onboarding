---
title: "DB2"
date: 2022-04-20T14:13:01+02:00
draft: true
domain: Middleware
category: RDBMS
categoryId: 17
status: Strategic
Owner: TBD
tags: ["standard", "middleware", "RDBMS"]
categories: ["standards"]
---
