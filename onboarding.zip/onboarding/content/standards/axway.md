---
title: "Axway API Gateway"
date: 2022-04-20T14:13:01+02:00
draft: true
domain: Security
category: API Security
categoryId: 15
status: Strategic
Owner: TBD
tags: ["standard", "security", "API Gateway", "Axway"]
categories: ["standards"]
---
