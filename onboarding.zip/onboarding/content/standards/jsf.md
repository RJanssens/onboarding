---
title: "Java Server Faces (JSF)"
date: 2022-04-20T14:13:01+02:00
draft: true
domain: Development
category: Front-end framework
categoryId: 9
status: Tactical
Owner: TBD
tags: ["standard", "front-end framework", "java"]
categories: ["standards"]
---
