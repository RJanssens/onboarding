---
title: "DatCFG"
date: 2022-04-20T14:13:01+02:00
draft: true
domain: Kubernetes
category: Configuration Management
categoryId: 26
status: Strategic
Owner: TBD
tags: ["standard", "configuration management", "JEE"]
categories: ["standards"]
---
