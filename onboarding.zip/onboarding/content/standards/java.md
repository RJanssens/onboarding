---
title: "Java"
date: 2022-04-20T14:13:01+02:00
draft: true
domain: Development
category: Language
categoryId: 1
status: Strategic
Owner: TBD
tags: ["standard", "language", "java"]
categories: ["standards"]
---
