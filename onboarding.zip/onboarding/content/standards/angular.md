---
title: "Angular"
date: 2022-04-20T14:13:01+02:00
draft: true
domain: Development
category: Front-end framework
categoryId: 9
status: Strategic
Owner: TBD
tags: ["standard", "front-end", "angular"]
categories: ["standards"]
---
