---
title: "Istio"
date: 2022-04-20T14:13:01+02:00
draft: true
domain: Kubernetes
category: Container Orchestration
categoryId: 24
status: Service Mesh
Owner: TBD
tags: ["standard", "kubernetes", "service mesh"]
categories: ["standards"]
---
